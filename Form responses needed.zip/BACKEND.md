# Telethongram — backend handoff

Telethongram is a web client for chats the user has explicitly opted in from
their own Telegram account. The backend is an **MTProto client running as the
user** (Telethon or equivalent). A chat becomes visible in this web client when
someone types `.addweb` in it.

The frontend is complete and renders only what the API returns. Nothing in the
UI talks to Telegram, and nothing in the UI knows what `.addweb` is.

---

## Files

| File | What it is |
| --- | --- |
| `Messenger.dc.html` | The entire client — three-column shell, conversation, panels, settings, onboarding. Presentation only. |
| `api.js` | The one data boundary. `window.API` — every read, write and the real-time subscription. All bodies are placeholders. |
| `BACKEND.md` | This document. |

Port procedure: replace each function body in `api.js` with a `fetch()` against
the bridge service, and replace `subscribeToUpdates` with a WebSocket. No file
other than `api.js` changes.

---

## Envelope

Every function is `async` and resolves to one of:

```js
{ ok: true,  data: … }
{ ok: false, error: "human-readable string" }
```

Errors are **values, not throws**. The `error` string is rendered verbatim to
the user in the inline error state, so write it for a person: *"Could not reach
the Telegram bridge (MTProto session expired)."*

---

## Data shapes

### Chat

```js
{
  id:            "c_city",              // stable client id
  tgChatId:      -1001884420011,        // Telegram peer id
  type:          "private" | "group" | "channel" | "saved",
  title:         "Desk — City",
  username:      "@thecolumn" | null,
  avatarUrl:     "https://cdn.../avatar/…" | null,   // backend-proxied
  initials:      "DC",                  // fallback when avatarUrl is null
  enabled:       true,                  // always true in getChats()
  addedAt:       1750000000000,         // when .addweb ran
  lastMessage:   Message | null,        // denormalised for the list row
  unreadCount:   2,
  pinned:        false,
  muted:         false,
  archived:      false,
  memberCount:   6,                     // subscribers for channels
  online:        true,                  // private chats only
  lastSeen:      1750000000000,         // private chats only
  draft:         "…",                   // server-side draft, optional
  members:       ["u_me", …],           // groups
  admins:        ["u_june"],
  permissions:   { send, media, invite, pin },
  signMessages:  true,                  // channels
  inviteLink:    "t.me/+cityDesk"
}
```

**There is no "all chats" view.** `getChats()` returns exactly the enabled set
and the chat list renders exactly that. Folder tabs (All / Unread / Groups /
Channels / Archived) filter *within* the enabled set, client-side.

### Message

```js
{
  id:            "m41",
  tgMessageId:   40041,
  chatId:        "c_city",
  senderId:      "u_june",
  senderName:    "June Ashworth",
  senderColor:   3,                     // PALETTE INDEX 0–7, never a hex
  outgoing:      false,
  type:          "text" | "photo" | "video" | "voice" | "file" |
                 "sticker" | "gif" | "location" | "contact" | "poll",
  text:          "…",                   // caption lives in media.caption
  media:         { … } | null,          // shape per type, below
  link:          { site, title, desc } | null,   // link preview card
  replyTo:       "m38" | null,
  forwardedFrom: "Mira Okonkwo" | null,
  edited:        false,
  reactions:     { "👍": ["u_tomas","u_june"] },
  status:        "sending"|"sent"|"delivered"|"read"|"failed",
  date:          1750000000000,
  pinned:        false
}
```

`senderColor` is an **index into the client's sender palette**, not a colour.
The client owns eight sender colours tuned for contrast against the bubble in
both light and dark themes; sending a hex from the backend would break dark
mode. Assign the index however you like (hash of the Telegram user id is fine)
as long as it is stable per user.

### `media` by type

| type | media |
| --- | --- |
| `photo` | `{ photos: [{url, label, width, height}], caption }` |
| `video` | `{ url, thumbUrl, label, duration }` |
| `voice` | `{ url, duration, wave: [int…] }` — waveform peaks, 0–32 |
| `file` | `{ url, fileName, fileSize, fileKind, mime }` |
| `sticker` | `{ emoji, url }` |
| `gif` | `{ url, label }` |
| `location` | `{ lat, lon, place, sub }` |
| `contact` | `{ name, phone, note, userId }` |
| `poll` | `{ question, options: [{text, votes}], totalVotes, voted }` |

---

## Function contracts

### Reads

| Function | Returns |
| --- | --- |
| `getChats()` | `[Chat]` — the enabled set, any order (client sorts) |
| `getChat(chatId)` | `Chat` |
| `getMessages(chatId, {before, limit})` | `[Message]` ascending by `date`; `before` is a ms timestamp for upward pagination; `limit` defaults to 40 |
| `getProfile(userId)` | `{id, name, username, phone, bio, initials, avatarUrl, online, lastSeen, blocked}` |
| `getSharedMedia(chatId, type)` | `type` ∈ `media`\|`files`\|`links`\|`voice` → `[{label, sub, url}]`; omit `type` for all four keyed |
| `searchAll(query)` | `{chats: [Chat], messages: [Message + chatTitle], contacts: [User]}` |
| `searchInChat(chatId, query)` | `[Message]` |
| `getContacts()` | `[User]` |
| `getSettings()` | `Settings` (below) |

### Writes

| Function | Notes |
| --- | --- |
| `sendMessage(chatId, payload)` | `payload = {type, text?, media?, replyTo?}`. Returns the created message with `status:'sending'` **immediately** |
| `editMessage(chatId, messageId, text)` | |
| `deleteMessage(chatId, messageId, forEveryone)` | |
| `reactToMessage(chatId, messageId, emoji)` | Toggles the current user's reaction |
| `forwardMessages(fromChatId, messageIds, toChatId)` | |
| `markRead(chatId)` | |
| `setTyping(chatId)` | Fire-and-forget, throttled client-side to ~1 per 3 s |
| `uploadFile(file, onProgress)` | `onProgress({loaded, total, percent})`; resolves `{url, name, size, mime}` |
| `pinMessage(chatId, messageId)` | |
| `pinChat` / `muteChat` / `archiveChat` | Toggles, return the updated `Chat` |
| `updateSettings(payload)` | Returns the whole merged `Settings` |

Also present and equally placeholder: `votePoll`, `clearHistory`, `deleteChat`,
`createChat`, `addMembers`, `setPermission`, `setSignMessages`, `blockUser`,
`unblockUser`, `getBlocked`, `getSessions`, `terminateSession`,
`updateProfile`, `requestCode`, `verifyCode`, `setName`.

`deleteChat(chatId)` **does not leave the Telegram chat** — it sets
`enabled:false` so the chat drops out of the web client only.

---

## Real-time layer

One seam:

```js
const unsubscribe = API.subscribeToUpdates({
  onNewMessage:      ({chatId, message}) => {},
  onMessageEdited:   ({chatId, message}) => {},
  onMessageDeleted:  ({chatId, messageId, forEveryone}) => {},
  onReaction:        ({chatId, messageId, reactions}) => {},
  onTyping:          ({chatId, userId, userName, typing}) => {},
  onPresence:        ({userId, online, lastSeen}) => {},
  onReadReceipt:     ({chatId, messageId, status}) => {},
  onChatAdded:       ({chat}) => {},
  onChatRemoved:     ({chatId}) => {},
  onConnectionChange:({status}) => {}   // connecting | online | reconnecting | offline
});
```

Currently a local emitter. **Production replaces it with a single WebSocket**
(SSE also works — typing still goes out over HTTP) fed by MTProto update
events. Handler names and payload shapes stay identical; only the transport
changes.

- `onChatAdded` exists so a chat appears the moment someone runs `.addweb`,
  with no refresh. The client inserts the row live and flashes it for two
  seconds. Emit it as soon as the command is processed.
- `onChatRemoved` is the mirror (`.delweb`, or the user removing the chat here).
- `onConnectionChange` drives the banner across the top of the app. Emit
  `connecting` on socket open, `reconnecting` on retry, `offline` when retries
  are exhausted, `online` when the backlog has been drained. The client shows
  nothing at all while `online`.

Polling is **not** sufficient for message delivery, typing, presence or read
receipts. It is acceptable only as a degraded fallback when the socket cannot
open.

---

## View-state contract

Every async view in the client is in exactly one of four states, and the state
comes from the response — never from a timer.

| State | Trigger | UI |
| --- | --- | --- |
| `loading` | request in flight | skeleton shaped like the real content (chat rows, message bubbles) |
| `success` | `{ok:true}` with items | content |
| `empty` | `{ok:true}` with zero items | designed empty state |
| `error` | `{ok:false}` | the backend's `error` string inline, plus a Retry action that re-issues the same call |

The critical empty state is the chat list with nothing enabled:

> **No chats yet** — run `.addweb` in any Telegram chat to add it here.

with the command set in the monospace face.

**Optimistic sending** stays: `sendMessage` returns immediately with
`status:'sending'` and the bubble paints with a clock icon; the real status
arrives via the return value or `onReadReceipt`. `status:'failed'` renders a
retry affordance on the bubble. Give every outgoing message a client id so the
socket echo can be de-duplicated against the optimistic copy.

---

## Settings

Server-owned, no `localStorage`, no client fallback:

```js
{
  theme: "light"|"dark"|"system",
  bubble: "cyan"|"magenta"|"ink",
  wallpaper: "paper"|"grid"|"tint",
  fontSize: 16,                       // 13–20
  lastSeen | profilePhoto | calls: "everybody"|"contacts"|"nobody",
  twoStep: false,
  notifications: { global, sound, preview },
  language: "English (US)"
}
```

A change should broadcast to the account's other sessions over the same socket.

---

## Implementation notes

### MTProto specifics

- Run one long-lived Telethon client per user session, keyed by the string
  session. Never expose the session string to the browser.
- Telegram ids are `int64`. Serialise `tgChatId` / `tgMessageId` as numbers only
  if you are certain they fit; otherwise send strings. The client treats both as
  opaque.
- Map `updateNewMessage`, `updateEditMessage`, `updateDeleteMessages`,
  `updateMessageReactions`, `updateUserTyping` / `updateChatUserTyping`,
  `updateUserStatus` and `updateReadHistoryOutbox` onto the handler names above.
  Do not leak raw MTProto objects to the client.
- Respect FLOOD_WAIT. Queue and back off server-side; the client has no rate
  limiting of its own beyond typing throttle.
- Channels: `memberCount` is the subscriber count; `signMessages` mirrors the
  channel flag.

### `.addweb` and control commands — backend responsibility

Command handling lives **entirely** in the backend:

1. Watch outgoing messages for `.addweb` (and `.delweb`, and any future
   commands) in any chat.
2. On match: flip `enabled` for that chat, emit `onChatAdded` / `onChatRemoved`.
3. **Filter the command message itself out of the history and out of the update
   stream.** Also filter any bot/system acknowledgement the command produces.

The frontend renders whatever it receives and contains no command-filtering
logic. If `.addweb` shows up as a message bubble, that is a backend bug.

### Media proxying

The client never receives Telegram file references, and never calls Telegram.

- Download each media item server-side, cache it (object storage or disk),
  and hand the client a plain HTTPS URL on your own origin:
  `/media/{chatId}/{messageId}/{variant}`.
- Serve a thumbnail variant for grids and a full variant for the lightbox.
- Signed, expiring URLs are fine — the client treats `avatarUrl`, `media.url`
  and `thumbUrl` as opaque strings and re-fetches whatever it is given.
- Voice waveforms: decode server-side into the `wave` peak array. The client
  will not decode audio.
- Uploads go the other way: browser → `uploadFile` (multipart, progress events)
  → your storage → `sendMessage` with the returned handle. The browser never
  uploads to Telegram.

### Auth

The onboarding flow in the client (phone → 5-digit code → name, plus QR) maps
onto `requestCode` / `verifyCode` / `setName`, which in production wrap
Telethon's `send_code_request` / `sign_in`. Two-factor password and QR login
both need one extra step each; add them as `verifyPassword(password)` and
`getLoginQr()` when you wire it up — the UI already has the QR screen.
