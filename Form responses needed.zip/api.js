/* api.js — Telethongram frontend data boundary.
   ─────────────────────────────────────────────────────────────────────────
   The UI never touches Telegram. Everything goes through the functions below.
   Every function is async and resolves to {ok:true, data} or {ok:false, error}.
   Every body here is a PLACEHOLDER: swap it for a fetch() against the
   MTProto bridge service and no UI code changes. See BACKEND.md.
   ───────────────────────────────────────────────────────────────────────── */
(function () {
  const ok = (data) => ({ ok: true, data });
  const err = (error) => ({ ok: false, error });
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const lat = () => 140 + Math.random() * 240;
  const uid = (p) => p + '_' + Math.random().toString(36).slice(2, 9);

  const DAY = 86400000;
  const now = Date.now();
  const t = (daysAgo, h, m) => { const d = new Date(now - daysAgo * DAY); d.setHours(h, m, 0, 0); return d.getTime(); };

  /* Sender colour is a PALETTE INDEX (0–7), never a hex. The client resolves
     it against the active theme so contrast holds in light and dark. */
  const colorOf = (id) => { let h = 0; for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) % 997; return h % 8; };

  const me = { id: 'u_me', tgUserId: 771002, name: 'Rosalind Hale', username: '@rhale', phone: '+1 202 555 0148', bio: 'Deputy editor, City desk. Filing since 2011.', initials: 'RH', avatarUrl: null, online: true };

  const users = [
    me,
    { id: 'u_mira', tgUserId: 771019, name: 'Mira Okonkwo', username: '@mira', phone: '+1 202 555 0119', bio: 'Investigations. Slow stories.', initials: 'MO', avatarUrl: null, online: true },
    { id: 'u_anton', tgUserId: 771077, name: 'Anton Reyes', username: '@areyes', phone: '+1 202 555 0177', bio: 'Photo desk. Available nights.', initials: 'AR', avatarUrl: null, online: false, lastSeen: now - 3600e3 },
    { id: 'u_delphine', tgUserId: 771088, name: 'Delphine Aubert', username: '@delphine', phone: '+33 6 12 55 01 88', bio: 'Paris bureau.', initials: 'DA', avatarUrl: null, online: false, lastSeen: now - 26 * 3600e3 },
    { id: 'u_ivo', tgUserId: 771022, name: 'Ivo Marek', username: '@ivo', phone: '+420 601 555 022', bio: 'Freelance, Central Europe.', initials: 'IM', avatarUrl: null, online: false, lastSeen: now - 5 * DAY },
    { id: 'u_june', tgUserId: 771002, name: 'June Ashworth', username: '@june', phone: '+1 202 555 0102', bio: 'Standards editor.', initials: 'JA', avatarUrl: null, online: true },
    { id: 'u_tomas', tgUserId: 771063, name: 'Tomas Beck', username: '@tbeck', phone: '+1 202 555 0163', bio: 'Data reporting.', initials: 'TB', avatarUrl: null, online: false, lastSeen: now - 900e3 },
    { id: 'u_priya', tgUserId: 771090, name: 'Priya Raman', username: '@priya', phone: '+1 202 555 0190', bio: 'Night editor.', initials: 'PR', avatarUrl: null, online: true },
    { id: 'u_ken', tgUserId: 771034, name: 'Ken Ellery', username: '@ken', phone: '+1 202 555 0134', bio: 'Copy chief.', initials: 'KE', avatarUrl: null, online: false, lastSeen: now - 7200e3 }
  ];
  const userById = (id) => users.find((u) => u.id === id) || { id, name: 'Unknown', initials: '??' };

  let blocked = ['u_ivo'];

  /* Chats the backend reports as ENABLED — i.e. someone ran `.addweb` in them.
     There is no "all chats" view; this list is the whole client. */
  const chats = [
    { id: 'c_saved', tgChatId: 771002, type: 'saved', title: 'Saved Messages', username: null, avatarUrl: null, initials: '★', enabled: true, addedAt: t(30, 9, 0), pinned: true, muted: false, archived: false, unreadCount: 0, memberCount: 1, members: ['u_me'] },
    { id: 'c_city', tgChatId: -1001884420011, type: 'group', title: 'Desk — City', username: null, avatarUrl: null, initials: 'DC', enabled: true, addedAt: t(21, 10, 12), pinned: true, muted: false, archived: false, unreadCount: 2, memberCount: 6, members: ['u_me', 'u_mira', 'u_anton', 'u_june', 'u_tomas', 'u_priya'], admins: ['u_me', 'u_june'], inviteLink: 't.me/+cityDesk', permissions: { send: true, media: true, invite: true, pin: false } },
    { id: 'c_mira', tgChatId: 771019, type: 'private', title: 'Mira Okonkwo', username: '@mira', avatarUrl: null, initials: 'MO', enabled: true, addedAt: t(19, 8, 0), userId: 'u_mira', pinned: false, muted: false, archived: false, unreadCount: 0 },
    { id: 'c_column', tgChatId: -1001884420099, type: 'channel', title: 'The Column', username: '@thecolumn', avatarUrl: null, initials: 'TC', enabled: true, addedAt: t(17, 7, 0), pinned: false, muted: false, archived: false, unreadCount: 4, memberCount: 12480, subscriberCount: 12480, admins: ['u_me'], signMessages: true, inviteLink: 't.me/thecolumn' },
    { id: 'c_photo', tgChatId: -1001884420033, type: 'group', title: 'Photo Desk', username: null, avatarUrl: null, initials: 'PD', enabled: true, addedAt: t(15, 12, 0), pinned: false, muted: true, archived: false, unreadCount: 3, memberCount: 4, members: ['u_me', 'u_anton', 'u_priya', 'u_tomas'], admins: ['u_anton'], inviteLink: 't.me/+photodesk', permissions: { send: true, media: true, invite: false, pin: false } },
    { id: 'c_anton', tgChatId: 771077, type: 'private', title: 'Anton Reyes', username: '@areyes', avatarUrl: null, initials: 'AR', enabled: true, addedAt: t(14, 18, 0), userId: 'u_anton', pinned: false, muted: false, archived: false, unreadCount: 0, draft: 'the contact sheets from Tuesday —' },
    { id: 'c_copy', tgChatId: -1001884420044, type: 'group', title: 'Copy & Standards', username: null, avatarUrl: null, initials: 'CS', enabled: true, addedAt: t(12, 9, 0), pinned: false, muted: false, archived: false, unreadCount: 0, memberCount: 3, members: ['u_me', 'u_june', 'u_ken'], admins: ['u_june'], inviteLink: 't.me/+copystandards', permissions: { send: true, media: false, invite: false, pin: false } },
    { id: 'c_delphine', tgChatId: 771088, type: 'private', title: 'Delphine Aubert', username: '@delphine', avatarUrl: null, initials: 'DA', enabled: true, addedAt: t(11, 5, 0), userId: 'u_delphine', pinned: false, muted: false, archived: false, unreadCount: 1 },
    { id: 'c_allstaff', tgChatId: -1001884420055, type: 'channel', title: 'Newsroom All-Staff', username: '@bsallstaff', avatarUrl: null, initials: 'NA', enabled: true, addedAt: t(9, 10, 0), pinned: false, muted: true, archived: false, unreadCount: 0, memberCount: 431, subscriberCount: 431, admins: ['u_june'], signMessages: false, inviteLink: 't.me/bsallstaff' },
    { id: 'c_ivo', tgChatId: 771022, type: 'private', title: 'Ivo Marek', username: '@ivo', avatarUrl: null, initials: 'IM', enabled: true, addedAt: t(8, 14, 0), userId: 'u_ivo', pinned: false, muted: false, archived: true, unreadCount: 0 },
    { id: 'c_gallery', tgChatId: -1001884420066, type: 'group', title: 'Press Gallery', username: null, avatarUrl: null, initials: 'PG', enabled: true, addedAt: t(7, 12, 0), pinned: false, muted: true, archived: true, unreadCount: 0, memberCount: 3, members: ['u_me', 'u_ivo', 'u_delphine'], admins: ['u_ivo'], inviteLink: 't.me/+pressgallery', permissions: { send: true, media: true, invite: true, pin: false } }
  ];

  let seq = 0;
  const M = (chatId, senderId, date, type, extra) => {
    const u = userById(senderId);
    return Object.assign({
      id: 'm' + ++seq,
      tgMessageId: 40000 + seq,
      chatId: chatId,
      senderId: senderId,
      senderName: u.name,
      senderColor: colorOf(senderId),
      outgoing: senderId === 'u_me',
      type: type,
      text: '',
      media: null,
      link: null,
      replyTo: null,
      forwardedFrom: null,
      edited: false,
      reactions: {},
      status: senderId === 'u_me' ? 'read' : 'delivered',
      date: date,
      pinned: false
    }, extra);
  };

  const messages = [
    M('c_city', 'u_june', t(2, 9, 12), 'text', { text: 'Morning. Budget meeting moved to 10:30 — the mayor’s office is briefing at 10.' }),
    M('c_city', 'u_tomas', t(2, 9, 20), 'text', { text: 'I have the permit numbers cleaned up. Three years, by ward.' }),
    M('c_city', 'u_tomas', t(2, 9, 21), 'file', { media: { fileName: 'permits_by_ward_2021-2024.csv', fileSize: '2.4 MB', fileKind: 'csv', url: '/media/f/40003' } }),
    M('c_city', 'u_me', t(2, 9, 34), 'text', { text: 'This is the spine of the piece. Can you break out the denials separately?', reactions: { '👍': ['u_tomas', 'u_june'] } }),
    M('c_city', 'u_mira', t(1, 11, 2), 'photo', { media: { photos: [{ url: null, label: 'site fence, 4th & Eaton' }, { url: null, label: 'crane detail' }, { url: null, label: 'notice board' }], caption: 'Shot these on the walk over. The notice was posted after the hearing.' } }),
    M('c_city', 'u_priya', t(1, 11, 40), 'voice', { media: { duration: '0:34', url: '/media/v/40006', wave: [3, 6, 12, 8, 15, 22, 14, 9, 18, 26, 20, 11, 7, 13, 19, 24, 16, 8, 5, 10, 14, 9, 6, 4] } }),
    M('c_city', 'u_me', t(1, 12, 5), 'text', { text: 'Filed the nut graf. Draft is in the CMS: desk.broadsheet.press/story/4482', link: { site: 'desk.broadsheet.press', title: 'City permits: the two-year backlog nobody logged', desc: 'Draft — City desk — 1,840 words — awaiting standards read.' } }),
    M('c_city', 'u_june', t(1, 12, 11), 'text', { text: 'Reading it now. Hold the headline until legal clears the word “concealed”.', reactions: { '👀': ['u_me'] } }),
    M('c_city', 'u_ken', t(1, 12, 30), 'text', { text: 'Style note for the table caption — set the figures in `tnum` so the columns line up.' }),
    M('c_city', 'u_anton', t(0, 8, 15), 'text', { text: 'Do we want the crane frame or the notice board for the lead art?' }),
    M('c_city', 'u_me', t(0, 8, 22), 'poll', { media: { question: 'Lead art for the permits story', options: [{ text: 'Crane detail', votes: 4 }, { text: 'Notice board', votes: 7 }, { text: 'Site fence, wide', votes: 2 }], totalVotes: 13, voted: null }, pinned: true }),
    M('c_city', 'u_priya', t(0, 8, 51), 'location', { media: { place: '4th & Eaton, Ward 3', sub: 'Live location — 15 min', lat: 38.9, lon: -77.03 } }),
    M('c_city', 'u_mira', t(0, 9, 4), 'text', { text: 'On my way there now. Will call after the site visit.' }),
    M('c_city', 'u_ken', t(0, 9, 30), 'contact', { media: { name: 'Harriet Vance', phone: '+1 202 555 0170', note: 'Ward 3 planning clerk — happy to talk on background.' } }),
    M('c_city', 'u_me', t(0, 9, 44), 'text', { text: 'Perfect. Adding her to the callback list.', edited: true }),
    M('c_city', 'u_june', t(0, 10, 2), 'sticker', { media: { emoji: '🗞️' } }),

    M('c_mira', 'u_mira', t(3, 16, 10), 'text', { text: 'Are you free to look at the FOIA response? It’s 400 pages of nothing and one useful table.' }),
    M('c_mira', 'u_me', t(3, 16, 14), 'text', { text: 'Send it over. I’ll take the table.' }),
    M('c_mira', 'u_mira', t(3, 16, 15), 'file', { media: { fileName: 'FOIA-2024-1183_response.pdf', fileSize: '18.7 MB', fileKind: 'pdf', url: '/media/f/40018' } }),
    M('c_mira', 'u_me', t(0, 7, 55), 'text', { text: 'Page 212. That’s the one they didn’t want redacted properly.', reactions: { '🔥': ['u_mira'] } }),
    M('c_mira', 'u_mira', t(0, 8, 2), 'text', { text: 'Oh that is extremely good.' }),
    M('c_mira', 'u_mira', t(0, 8, 3), 'gif', { media: { label: 'reaction gif — slow clap', url: '/media/g/40021' } }),
    M('c_mira', 'u_me', t(0, 8, 30), 'video', { media: { label: 'hearing_clip_0412.mp4', duration: '1:12', url: '/media/vid/40022' } }),

    M('c_column', 'u_me', t(4, 7, 0), 'text', { text: 'The Column, No. 118 — on the quiet economics of parking minimums.', link: { site: 'broadsheet.press', title: 'The quiet economics of parking minimums', desc: 'Every space costs someone. Usually not the driver.' }, reactions: { '👏': ['u_mira', 'u_june', 'u_tomas'], '🧠': ['u_priya'] } }),
    M('c_column', 'u_me', t(1, 7, 0), 'text', { text: 'No. 119 goes out Thursday. Subject: what a hearing transcript hides.' }),
    M('c_column', 'u_me', t(0, 7, 5), 'photo', { media: { photos: [{ url: null, label: 'issue 119 cover plate' }], caption: 'Cover plate for Thursday.' } }),
    M('c_column', 'u_me', t(0, 7, 30), 'text', { text: 'Reader mail is open until noon.' }),

    M('c_photo', 'u_anton', t(0, 6, 40), 'text', { text: 'Contact sheets are up on the shared drive.' }),
    M('c_photo', 'u_priya', t(0, 6, 52), 'text', { text: 'Frames 40–58 are the usable ones.' }),
    M('c_photo', 'u_anton', t(0, 7, 1), 'photo', { media: { photos: [{ url: null, label: 'contact sheet A' }, { url: null, label: 'contact sheet B' }], caption: '' } }),
    M('c_anton', 'u_anton', t(1, 18, 20), 'text', { text: 'Let me know which frames you want pulled.' }),
    M('c_copy', 'u_ken', t(0, 9, 10), 'text', { text: 'Style note: it’s “ward 3” lowercase unless it opens the sentence.', pinned: true }),
    M('c_copy', 'u_june', t(0, 9, 12), 'text', { text: 'Pinned it.' }),
    M('c_delphine', 'u_delphine', t(0, 5, 30), 'text', { text: 'Sending the Paris budget lines tonight — the numbers moved again.' }),
    M('c_allstaff', 'u_june', t(6, 10, 0), 'text', { text: 'Reminder: the standards refresher is Friday at 3. Attendance is not optional.' }),
    M('c_ivo', 'u_ivo', t(12, 14, 0), 'text', { text: 'Invoice for the March assignment attached.' }),
    M('c_gallery', 'u_delphine', t(20, 12, 0), 'text', { text: 'Gallery passes for the session are ready at the desk.' }),
    M('c_saved', 'u_me', t(5, 20, 0), 'text', { text: 'Standing questions for any planning source: who signed, when, and what changed between drafts.' }),
    M('c_saved', 'u_me', t(0, 6, 10), 'text', { text: 'Call Harriet Vance back — Ward 3 clerk.' })
  ];

  let settings = {
    theme: 'light', bubble: 'cyan', wallpaper: 'paper', fontSize: 16,
    lastSeen: 'everybody', profilePhoto: 'contacts', calls: 'contacts', twoStep: false,
    notifications: { global: true, sound: true, preview: true },
    language: 'English (US)'
  };

  const sessions = [
    { id: 's1', device: 'Telethongram Web — Chrome, macOS', place: 'Washington, DC', current: true, date: now },
    { id: 's2', device: 'Telegram Desktop — macOS', place: 'Washington, DC', current: false, date: now - 2 * DAY },
    { id: 's3', device: 'Telegram iOS — iPhone 15', place: 'Baltimore, MD', current: false, date: now - 9 * DAY }
  ];

  /* ── real-time seam ─────────────────────────────────────────────────────
     One subscription point. Production replaces the emitter below with a
     WebSocket (or SSE) fed by MTProto updates; the handler names stay. */
  const HANDLER_NAMES = ['onNewMessage', 'onMessageEdited', 'onMessageDeleted', 'onReaction', 'onTyping', 'onPresence', 'onReadReceipt', 'onChatAdded', 'onChatRemoved', 'onConnectionChange'];
  const listeners = new Set();
  const emit = (name, payload) => listeners.forEach((h) => { if (typeof h[name] === 'function') { try { h[name](payload); } catch (e) { console.error(e); } } });

  const lastOf = (chatId) => {
    const list = messages.filter((m) => m.chatId === chatId && !m.deleted);
    return list[list.length - 1] || null;
  };
  const shape = (c) => Object.assign({}, c, {
    lastMessage: lastOf(c.id),
    online: c.userId ? !!(userById(c.userId).online) : undefined,
    lastSeen: c.userId ? userById(c.userId).lastSeen : undefined
  });

  /* Failure injection so the four view states can be exercised.
     API.__fail('getChats') makes the next call return {ok:false}. */
  let failNext = {};

  const API = {
    HANDLER_NAMES: HANDLER_NAMES,
    me: () => Object.assign({}, me),
    userById: userById,
    __fail(name) { failNext[name] = true; },

    /* ── reads ─────────────────────────────────────────────────────────── */
    async getChats() {
      await wait(lat());
      if (failNext.getChats) { failNext.getChats = false; return err('Could not reach the Telegram bridge (MTProto session expired).'); }
      return ok(chats.filter((c) => c.enabled).map(shape));
    },
    async getChat(chatId) {
      await wait(lat());
      const c = chats.find((x) => x.id === chatId && x.enabled);
      return c ? ok(shape(c)) : err('That chat is not enabled. Run .addweb in it first.');
    },
    async getMessages(chatId, opts) {
      const o = opts || {};
      await wait(lat());
      if (failNext.getMessages) { failNext.getMessages = false; return err('History request timed out.'); }
      let list = messages.filter((m) => m.chatId === chatId && !m.deleted);
      if (o.before) list = list.filter((m) => m.date < o.before);
      const limit = o.limit || 40;
      return ok(list.slice(-limit).map((m) => Object.assign({}, m)));
    },
    async getProfile(userId) {
      await wait(lat());
      const u = users.find((x) => x.id === userId);
      return u ? ok(Object.assign({ blocked: blocked.indexOf(userId) > -1 }, u)) : err('No such user');
    },
    async getSharedMedia(chatId, type) {
      await wait(lat());
      const list = messages.filter((m) => m.chatId === chatId && !m.deleted);
      const byType = {
        media: list.filter((m) => m.type === 'photo' || m.type === 'video' || m.type === 'gif')
          .reduce((a, m) => a.concat(m.type === 'photo' ? m.media.photos.map((p) => ({ label: p.label, url: p.url })) : [{ label: m.media.label, url: m.media.url }]), []),
        files: list.filter((m) => m.type === 'file').map((m) => ({ label: m.media.fileName, sub: m.media.fileSize, url: m.media.url })),
        links: list.filter((m) => m.link).map((m) => ({ label: m.link.title, sub: m.link.site })),
        voice: list.filter((m) => m.type === 'voice').map((m) => ({ label: m.senderName, sub: m.media.duration, url: m.media.url }))
      };
      return ok(type ? byType[type] || [] : byType);
    },
    async searchAll(query) {
      await wait(lat());
      const q = (query || '').trim().toLowerCase();
      if (!q) return ok({ chats: [], messages: [], contacts: [] });
      return ok({
        chats: chats.filter((c) => c.enabled && c.title.toLowerCase().indexOf(q) > -1).map(shape),
        contacts: users.filter((u) => u.id !== 'u_me' && (u.name.toLowerCase().indexOf(q) > -1 || (u.username || '').toLowerCase().indexOf(q) > -1)).map((u) => Object.assign({}, u)),
        messages: messages.filter((m) => !m.deleted && m.text && m.text.toLowerCase().indexOf(q) > -1).slice(0, 24)
          .map((m) => Object.assign({ chatTitle: (chats.find((c) => c.id === m.chatId) || {}).title }, m))
      });
    },
    async searchInChat(chatId, query) {
      await wait(120);
      const q = (query || '').trim().toLowerCase();
      if (!q) return ok([]);
      return ok(messages.filter((m) => m.chatId === chatId && !m.deleted && (m.text || '').toLowerCase().indexOf(q) > -1).map((m) => Object.assign({}, m)));
    },
    async getContacts() { await wait(lat()); return ok(users.filter((u) => u.id !== 'u_me').map((u) => Object.assign({}, u))); },
    async getSettings() { await wait(90); return ok(Object.assign({}, settings)); },
    async getBlocked() { await wait(lat()); return ok(blocked.map((id) => Object.assign({}, userById(id)))); },
    async getSessions() { await wait(lat()); return ok(sessions.map((s) => Object.assign({}, s))); },

    /* ── writes ────────────────────────────────────────────────────────── */
    async sendMessage(chatId, payload) {
      const msg = M(chatId, 'u_me', Date.now(), payload.type || 'text', Object.assign({ status: 'sending' }, payload));
      messages.push(msg);
      const chat = chats.find((c) => c.id === chatId);
      if (chat) chat.draft = '';
      await wait(120);
      if (failNext.sendMessage) {
        failNext.sendMessage = false;
        msg.status = 'failed';
        return ok(Object.assign({}, msg));
      }
      setTimeout(() => { msg.status = 'sent'; emit('onReadReceipt', { chatId, messageId: msg.id, status: 'sent' }); }, 500);
      setTimeout(() => { msg.status = 'delivered'; emit('onReadReceipt', { chatId, messageId: msg.id, status: 'delivered' }); }, 1300);
      setTimeout(() => { msg.status = 'read'; emit('onReadReceipt', { chatId, messageId: msg.id, status: 'read' }); }, 2600);
      if (chat && chat.type !== 'saved' && chat.type !== 'channel') API._autoReply(chat);
      return ok(Object.assign({}, msg));
    },
    _autoReply(chat) {
      const who = chat.type === 'private' ? chat.userId : ['u_june', 'u_mira', 'u_priya', 'u_tomas'][Math.floor(Math.random() * 4)];
      setTimeout(() => emit('onTyping', { chatId: chat.id, userId: who, userName: userById(who).name, typing: true }), 1500);
      setTimeout(() => {
        emit('onTyping', { chatId: chat.id, userId: who, userName: userById(who).name, typing: false });
        const lines = ['Got it — looking now.', 'Understood. I’ll come back on that this afternoon.', 'Agreed. Let’s hold it for the second edition.', 'Sending you the file in a moment.', 'That matches what the clerk told me.'];
        const reply = M(chat.id, who, Date.now(), 'text', { text: lines[Math.floor(Math.random() * lines.length)] });
        messages.push(reply);
        emit('onNewMessage', { chatId: chat.id, message: Object.assign({}, reply) });
      }, 4200);
    },
    async editMessage(chatId, messageId, text) {
      await wait(lat());
      const m = messages.find((x) => x.id === messageId && x.chatId === chatId);
      if (!m) return err('Message not found');
      m.text = text; m.edited = true;
      emit('onMessageEdited', { chatId, message: Object.assign({}, m) });
      return ok(Object.assign({}, m));
    },
    async deleteMessage(chatId, messageId, forEveryone) {
      await wait(lat());
      const m = messages.find((x) => x.id === messageId && x.chatId === chatId);
      if (!m) return err('Message not found');
      m.deleted = true; m.deletedForEveryone = !!forEveryone;
      emit('onMessageDeleted', { chatId, messageId, forEveryone: !!forEveryone });
      return ok({ chatId, messageId });
    },
    async reactToMessage(chatId, messageId, emoji) {
      await wait(90);
      const m = messages.find((x) => x.id === messageId);
      if (!m) return err('Message not found');
      m.reactions = m.reactions || {};
      const arr = m.reactions[emoji] || [];
      if (arr.indexOf('u_me') > -1) {
        m.reactions[emoji] = arr.filter((u) => u !== 'u_me');
        if (!m.reactions[emoji].length) delete m.reactions[emoji];
      } else m.reactions[emoji] = arr.concat('u_me');
      emit('onReaction', { chatId, messageId, reactions: m.reactions });
      return ok(Object.assign({}, m));
    },
    async forwardMessages(fromChatId, messageIds, toChatId) {
      await wait(lat());
      messageIds.forEach((id) => {
        const src = messages.find((x) => x.id === id && x.chatId === fromChatId);
        if (!src) return;
        const copy = M(toChatId, 'u_me', Date.now(), src.type, {
          text: src.text, media: src.media, link: src.link,
          forwardedFrom: src.senderName, status: 'sent'
        });
        messages.push(copy);
        emit('onNewMessage', { chatId: toChatId, message: Object.assign({}, copy) });
      });
      return ok({ count: messageIds.length });
    },
    async votePoll(chatId, messageId, index) {
      await wait(lat());
      const m = messages.find((x) => x.id === messageId);
      if (!m || m.type !== 'poll') return err('Poll not found');
      const p = m.media;
      if (p.voted != null) p.options[p.voted].votes--; else p.totalVotes++;
      p.options[index].votes++; p.voted = index;
      return ok(Object.assign({}, m));
    },
    async pinMessage(chatId, messageId) {
      await wait(lat());
      messages.forEach((x) => { if (x.chatId === chatId) x.pinned = false; });
      const m = messages.find((x) => x.id === messageId);
      if (!m) return err('Message not found');
      m.pinned = true;
      return ok(Object.assign({}, m));
    },
    async markRead(chatId) {
      await wait(60);
      const c = chats.find((x) => x.id === chatId);
      if (c) c.unreadCount = 0;
      return ok({ chatId });
    },
    async setTyping(chatId) { return ok({ chatId }); },
    async saveDraft(chatId, text) { const c = chats.find((x) => x.id === chatId); if (c) c.draft = text; return ok({ chatId }); },
    /* Progress is reported through the callback so the composer can show a
       real bar. Production: XHR upload events, or fetch + ReadableStream. */
    async uploadFile(file, onProgress) {
      const total = (file && file.size) || 2400000;
      for (let p = 0; p <= 100; p += 10) {
        await wait(70);
        if (typeof onProgress === 'function') onProgress({ loaded: Math.round(total * p / 100), total: total, percent: p });
      }
      return ok({ url: '/media/upload/' + uid('f'), name: (file && file.name) || 'upload.bin', size: '2.4 MB', mime: (file && file.type) || 'application/octet-stream' });
    },
    async pinChat(chatId) { const c = chats.find((x) => x.id === chatId); if (c) c.pinned = !c.pinned; await wait(80); return ok(shape(c)); },
    async muteChat(chatId) { const c = chats.find((x) => x.id === chatId); if (c) c.muted = !c.muted; await wait(80); return ok(shape(c)); },
    async archiveChat(chatId) { const c = chats.find((x) => x.id === chatId); if (c) c.archived = !c.archived; await wait(80); return ok(shape(c)); },
    async clearHistory(chatId) { messages.forEach((m) => { if (m.chatId === chatId) m.deleted = true; }); await wait(120); return ok({ chatId }); },
    /* Removing a chat here only removes it from the web client — it does not
       leave the Telegram chat. Backend flips enabled:false. */
    async deleteChat(chatId) {
      const c = chats.find((x) => x.id === chatId);
      if (c) c.enabled = false;
      await wait(120);
      emit('onChatRemoved', { chatId });
      return ok({ chatId });
    },
    async createChat(kind, title, memberIds) {
      await wait(300);
      const c = {
        id: uid('c'), tgChatId: -100188442 * 10 - seq, type: kind, title: title || 'Untitled',
        username: null, avatarUrl: null, initials: (title || 'Untitled').slice(0, 2).toUpperCase(),
        enabled: true, addedAt: Date.now(), pinned: false, muted: false, archived: false, unreadCount: 0,
        members: ['u_me'].concat(memberIds || []), memberCount: 1 + (memberIds || []).length, admins: ['u_me'],
        subscriberCount: kind === 'channel' ? 1 : undefined,
        inviteLink: 't.me/+' + Math.random().toString(36).slice(2, 8),
        permissions: { send: true, media: true, invite: true, pin: false }
      };
      if (kind === 'private' && memberIds && memberIds[0]) { c.userId = memberIds[0]; c.title = userById(memberIds[0]).name; c.initials = userById(memberIds[0]).initials; }
      chats.push(c);
      return ok(shape(c));
    },
    async addMembers(chatId, ids) {
      await wait(200);
      const c = chats.find((x) => x.id === chatId);
      if (!c) return err('No chat');
      c.members = (c.members || []).concat(ids.filter((i) => c.members.indexOf(i) < 0));
      c.memberCount = c.members.length;
      return ok(shape(c));
    },
    async setPermission(chatId, key, value) { const c = chats.find((x) => x.id === chatId); if (c && c.permissions) c.permissions[key] = value; await wait(60); return ok(shape(c)); },
    async setSignMessages(chatId, value) { const c = chats.find((x) => x.id === chatId); if (c) c.signMessages = value; await wait(60); return ok(shape(c)); },
    async blockUser(userId) { if (blocked.indexOf(userId) < 0) blocked.push(userId); await wait(120); return ok({ userId, blocked: true }); },
    async unblockUser(userId) { blocked = blocked.filter((b) => b !== userId); await wait(120); return ok({ userId, blocked: false }); },
    async updateSettings(payload) { settings = Object.assign({}, settings, payload); await wait(60); return ok(Object.assign({}, settings)); },
    async updateProfile(payload) { Object.assign(me, payload); await wait(120); return ok(Object.assign({}, me)); },
    async terminateSession(id) { const i = sessions.findIndex((s) => s.id === id); if (i > -1) sessions.splice(i, 1); await wait(200); return ok({ id }); },
    async requestCode(phone) { await wait(600); return phone && phone.length > 6 ? ok({ sent: true, hint: 'Any five digits will do' }) : err('Enter a valid number'); },
    async verifyCode(code) { await wait(600); return code && code.length === 5 ? ok({ token: uid('t'), isNew: code === '00000' }) : err('That code did not check out'); },
    async setName(first, last) { me.name = (first + ' ' + last).trim(); me.initials = (first[0] || '') + (last[0] || ''); await wait(300); return ok(Object.assign({}, me)); },

    /* ── subscription ──────────────────────────────────────────────────── */
    subscribeToUpdates(handlers) {
      const h = handlers || {};
      listeners.add(h);
      if (typeof h.onConnectionChange === 'function') {
        h.onConnectionChange({ status: 'connecting' });
        setTimeout(() => h.onConnectionChange({ status: 'online' }), 900);
      }
      API._startSim();
      return () => listeners.delete(h);
    },

    /* ── mock-only simulation. Delete when the socket lands. ───────────── */
    _startSim() {
      if (API._simOn) return;
      API._simOn = true;
      setInterval(() => {
        if (Math.random() < 0.22) {
          const live = chats.filter((c) => c.enabled && !c.archived);
          const c = live[1 + Math.floor(Math.random() * Math.min(4, live.length - 1))];
          if (!c) return;
          const who = c.type === 'private' ? c.userId : (c.members || ['u_june'])[1];
          emit('onTyping', { chatId: c.id, userId: who, userName: userById(who).name, typing: true });
          setTimeout(() => emit('onTyping', { chatId: c.id, userId: who, userName: userById(who).name, typing: false }), 3500);
        }
      }, 9000);
      setInterval(() => {
        const u = users[1 + Math.floor(Math.random() * (users.length - 1))];
        u.online = !u.online;
        if (!u.online) u.lastSeen = Date.now();
        emit('onPresence', { userId: u.id, online: u.online, lastSeen: u.lastSeen });
      }, 15000);
      /* Somebody runs `.addweb` in a new chat mid-session. */
      setTimeout(() => {
        const c = {
          id: 'c_wire', tgChatId: -1001884420077, type: 'group', title: 'Wire Watch', username: null, avatarUrl: null,
          initials: 'WW', enabled: true, addedAt: Date.now(), pinned: false, muted: false, archived: false,
          unreadCount: 1, memberCount: 5, members: ['u_me', 'u_priya', 'u_tomas', 'u_ken', 'u_mira'],
          admins: ['u_priya'], inviteLink: 't.me/+wirewatch', permissions: { send: true, media: true, invite: true, pin: false }
        };
        chats.push(c);
        messages.push(M('c_wire', 'u_priya', Date.now(), 'text', { text: 'Added this one to the web client — wire copy will land here from now on.' }));
        emit('onChatAdded', { chat: shape(c) });
      }, 20000);
      setTimeout(() => {
        emit('onConnectionChange', { status: 'reconnecting' });
        setTimeout(() => emit('onConnectionChange', { status: 'online' }), 3200);
      }, 42000);
    }
  };

  window.API = API;
})();
